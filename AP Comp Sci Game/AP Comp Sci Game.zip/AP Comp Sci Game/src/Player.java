import java.util.*;
public class Player extends Entity
{
    // 0 main hand, 1 offhand, 2 scabbard, 3-5 hip pouches, 6 quiver
    public Item[] equipped;
    public Weapon[] weapons;
    public Item[][] inventory;

    public Player()
    {
        super(2, 2, 2, 2, 2, 2);
    }

    // this goes 0-2
    public int playerAttack(int hand)
    {
        return weapons[hand].weaponAttack() + getStat(weapons[hand].getType());
    }
}
