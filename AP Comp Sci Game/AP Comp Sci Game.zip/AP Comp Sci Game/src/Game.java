import java.util.*;
import java.util.ArrayList;

public class Game
{
    public static ArrayList<Entity> turnOrder;
    // 0 = normal room, 1 = magic room, 2 = boss room
    public static int locator;
    public static ArrayList<Encounter> encounterList;
    public static ArrayList<Entity> combatOrder = new ArrayList<Entity>();

    public static void gooberAttack(Player p, Entity a)
    {
        try
        {
            p.takeDamage(a.attack1());
        }
        catch(Exception e)
        {
            System.out.println("You done goofed: either that's not actually a Goober, or attack1 does not exist, and it should. Talk to Jakob");
        }
    }

    public static boolean checkHP()
    {
        int enemyCount = combatOrder.size() - 1;
        int deadCount = 0;
        for(Entity e: combatOrder)
        {
            if(e.getClass() == Goober.class && e.getStat(5) <= 0)
                deadCount++;
            if(e.getClass() == Player.class && e.getStat(5) <= 0)
                return false;
        }
        if(deadCount != enemyCount)
            return false;
        return true;
    }

    public static void combat(Player p)
    {
        Scanner in = new Scanner(System.in);
        if (locator == 0)
        {
            encounterList.clear();
            combatOrder.add(new Guy());
            encounterList.add(new Encounter("The lid of a coffin lying on the floor is pried open by a bony hand. A skeleton jumps out, eyes fixed on you.", combatOrder));
        }
        else if (locator == 1)
        {
            encounterList.clear();
            combatOrder.add(new MagicChair());
            encounterList.add(new Encounter("A rotting table suddenly floats up off the ground, as various bits of debris begin swirling around it.", combatOrder));
        }
        else if (locator == 2)
        {
            encounterList.clear();
            combatOrder.add(new ArmoredDude());
            encounterList.add(new Encounter("Heralded by the clanking of plate armor and the stomping of metal feet, a massive armored warrior carrying an equally big axe enters the room.", combatOrder));
        }
        System.out.println(encounterList.get(0));
        if (combatOrder.get(0).getStat(4) > p.getStat(4))
        {
            combatOrder.add(p);
        }
        else
        {
            combatOrder.add(0, p);
        }
        while(checkHP()) {
            for (Entity a : combatOrder)
            {
                if (a.getStat(5) != 0)
                {
                    if (a.getClass() == Goober.class)
                    {
                        gooberAttack(p, a);
                        System.out.println("\n----------------------------\n");
                    }
                    else if (a.getClass() == Player.class)
                    {
                        System.out.println("Attack: ");
                        int attack = p.playerAttack(in.nextInt());
                        System.out.println(combatOrder + "\nTarget (0-n): ");
                        int target = in.nextInt();
                        combatOrder.get(target).takeDamage(attack);
                        System.out.println("\n----------------------------\n");
                    }
                }
            }
        }
    }
}
