public class Goober extends Entity
{
    public Goober()
    {
        super();
    }
    public Goober(int h, int sp, int st, int fi, int fo, int si)
    {
        super(h, sp, st, fi, fo, si);
    }
    public static int attack(int low, int high)
    {
        return (int)(Math.random() * (high - low + 1)) + low;
    }
}

